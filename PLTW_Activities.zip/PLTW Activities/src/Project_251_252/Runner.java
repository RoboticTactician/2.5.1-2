package Project_251_252;

/**
 * Activity 2.5.2
 *
 * The main class to run the PhraseSolverGame.
 */
public class Runner {
    public static void main(String[] args) {
        // Create an instance of the PhraseSolver class
        Cracker crackGame = new Cracker();

        // Start and manage the game
        crackGame.play();
    }
}
